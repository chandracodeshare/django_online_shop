from django.db import models


class Customer(models.Model):
    First_Name = models.CharField(max_length=50)
    Last_Name = models.CharField(max_length=50)
    Phone = models.CharField(max_length=15)
    Email = models.EmailField()
    Password = models.CharField(max_length=500)

    def register(self):
        self.save()

    @staticmethod
    def get_customer_by_email(Email):
        try:
            return Customer.objects.get(Email=Email)
        except:
            return False

    def isexist(self):
        if Customer.objects.filter(Email = self.Email):
            return True
        return False

