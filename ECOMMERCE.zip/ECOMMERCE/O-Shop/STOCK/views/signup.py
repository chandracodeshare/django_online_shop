from django.shortcuts import render, redirect
from STOCK.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        POSTdata = request.POST
        first_name = POSTdata.get('firstname')
        last_name = POSTdata.get('lastname')
        phone = POSTdata.get('phone')
        email = POSTdata.get('email')
        password = POSTdata.get('password')

        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }
        error_message = None

        customer = Customer(First_Name=first_name,
                            Last_Name=last_name,
                            Phone=phone, Email=email,
                            Password=password)
        error_message = self.validateCustomer(customer)

        if not error_message:

            print(first_name, last_name, phone, email, password)
            customer.Password = make_password(customer.Password)
            customer.register()
            return redirect('homepage')
        else:
            data = {

                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None
        if not customer.First_Name:
            error_message = "First name is required"
        elif len(customer.First_Name) < 4:
            error_message = "First name must be 4 char large or more"
        elif not customer.Last_Name:
            error_message = 'last name must required'
        elif len(customer.Last_Name) < 4:
            error_message = "last name must be 4char large or more"
        elif not customer.Phone:
            error_message = 'phone must required'
        elif len(customer.Phone) < 10:
            error_message = "phone no. must be 10 digit long"

        elif len(customer.Password) < 6:
            error_message = "password must be 6 char long"

        elif len(customer.Email) < 6:
            error_message = "eamil must be 6 char long"
        elif customer.isexist():
            error_message = "This email address is already exist"

        return error_message
